<?php

$this->load->view('include/header');
$this->load->view('include/leftside');
$this->load->view($content);
$this->load->view('include/footer');
